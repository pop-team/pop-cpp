#include <stdio.h>
#include "exception.ph"


int main(int argc, char **argv)
{
 
    printf("\nMain: Starting test..\n");
    ClassExcep e1, e2, e3;
    printf("Main: Object created..\n");

    for (int i=0; i<10; i++)
    {
      int j=i%5;
	    try
	    {
        printf("\n");
		    switch(j)
		    {
		      case 0 : e1.SeqSync(i/5) ; 
                   e2.SeqSync(i/5) ;
                   e3.SeqSync(i/5) ; break; 
		      case 1 : e1.ConcSync(i/5) ;
                   e2.ConcSync(i/5) ;
                   e3.ConcSync(i/5) ; break;
		      case 2 : e1.MutexSync(i/5) ;
                   e2.MutexSync(i/5) ;
                   e3.MutexSync(i/5) ; break;
		      case 3 : e1.SeqAsync(i/5) ;
                   e2.SeqAsync(i/5) ;
                   e3.SeqAsync(i/5) ; break;
          case 4 : e1.ConcAsync(i/5) ;
                   e2.ConcAsync(i/5) ;
                   e3.ConcAsync(i/5) ; break;
		      default: printf("Main. No call !\n"); break;
		    }
	    }

     catch (POPException *e)
       {printf("Main: has catched the POP exception (%d)!!\n", i);}    
     catch(std::exception& e)
       {printf("Main: has catched the exception '%s' (%d)!!\n", e.what(), i);}
     catch(int e)
       {printf("Main: has catched the exception %d (%d)!!\n", e, i);}
     catch(...)
       {printf("Main: has catched the exception (%d)!!\n", i);}

    } 
    printf("Main: test succeeded, destroying objects...\n");
    return 0;
}

