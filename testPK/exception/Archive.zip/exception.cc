#include <stdio.h>
#include "exception.ph"
#include "IOExceptions.h"

ClassExcep::ClassExcep()
{
  IOException a("My Exception Constructor", "ICI");
  printf("Object ClassExcep starting on localhost\n");
  e = -1;
  //throw a;
}

ClassExcep::~ClassExcep()
{
  printf("Object: Destroying the ClassExcep object...\n");
}

void ClassExcep::SeqSync(int i)
{
  IOException a("Object: My Exception SeqSync", "ICI");
  if (i==0) throw a; 
  else
  {
    e = 1;
    throw e;
  }
}

void ClassExcep::ConcSync(int i)
{
  IOException b("Object: My Exception ConcSync", "ICI");
  if (i==0) throw b;
  else
  {
    e = 2;
    throw e;
  }
}


void ClassExcep::MutexSync(int i)
{
  IOException b("Object: My Exception MutexSync", "ICI");
  if (i==0) throw b;
  else
  {
    e = 3;
    throw e;
  }
}

void ClassExcep::SeqAsync(int i)
{
  sleep(2); 
  IOException b("Object: My Exception SeqAsync", "ICI");
  if (i==0) throw b;
  else
  {
    e = 4;
    throw e;
  }
}

void ClassExcep::ConcAsync(int i)
{
  sleep(1);
  IOException b("Object: My Exception ConcAsync", "ICI");
  if (i==0) throw b;
  else
  {
    e = 5;
    throw e;
  }
}


@pack(ClassExcep);

