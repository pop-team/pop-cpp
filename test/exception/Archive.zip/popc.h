#ifndef _PAROC_
#define parclass class
#define seq 
#define async
#define sync
#define conc
#define mutex
#define paroc_string char*
#endif

#ifdef _PAROC_
#define printf rprintf
#endif


