#include "POPCobject.ph"
#include "structdata.h"
#include <stdio.h>

void main(int argc, char** argv)

{
   
   POPCobject o1, o2;
   StructData d;

   printf("Debut du test...\n");
   printf(" call to m2\n"); sleep(1);
   o1.m2(o2);
   printf(" call to m4\n"); sleep(1);
   o1.m4(d);
   printf(" call to m300\n"); sleep(1);
   o1.m300(d);
   printf(" call to 400\n"); sleep(1);
   o1.m400(d);
   //printf(" call to m5\n"); sleep(1);
   //o1.m5(&o2);
   //printf(" call to m6\n"); sleep(1);
   //o1.m6(&o2);
   //printf(" call to m7\n"); sleep(1);
   //o1.m7(&d);
   //printf(" call to m8\n"); sleep(1);
   //o1.m8(&d);
   printf(" call to m10\n"); sleep(1);
   o2=o1.m10();
   printf(" call to m12\n"); sleep(1);
   d=o1.m12();
   printf("...Fin du test\n");

} 
  