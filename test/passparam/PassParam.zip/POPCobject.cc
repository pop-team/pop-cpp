#include "POPCobject.ph"
#include <unistd.h>
#include <stdio.h>

POPCobject::POPCobject()
{
  printf("  POPCobject created on machine \"%s\"\n", (const char*)paroc_system::GetHost()); 
}

POPCobject::~POPCobject()
{
  printf("  POPCobject on machine \"%s\" is being destroyed\n", (const char*)paroc_system::GetHost()); 
}

//void POPCobject::m1(POPCobject &o) {printf("  m1 called\n");}
void POPCobject::m2(POPCobject &o) {printf("  m2 called\n");}

/*void POPCobject::m100(POPCobject o)
{printf("  m100 called\n");
o.m2(o);
}*/

/*void POPCobject::m200(POPCobject o)
{printf("M200 called\n");
o.m2(o);
}*/

//void POPCobject::m3(StructData &d) {printf("  m3 called\n");}
void POPCobject::m4(StructData &d) {printf("  m4 called\n");}

void POPCobject::m300(StructData d) {printf("  m300 called\n");}
void POPCobject::m400(StructData d) {printf("  m400 called\n");}


void POPCobject::m5(POPCobject *o) {printf("  m5 called\n");}
void POPCobject::m6(POPCobject *o) {printf("  m6 called\n");}

void POPCobject::m7(StructData *d) {printf("  m7 called\n");}
void POPCobject::m8(StructData *d) {printf("  m8 called\n");}

//POPCobject POPCobject::m9() {printf("  m9 called\n");}
POPCobject POPCobject::m10()
{
  POPCobject o;
  printf("  m10 called\n");
  return o;
}

//StructData POPCobject::m11() {printf("  m11 called\n");}
StructData POPCobject::m12()
{
  StructData d;
  printf("  m12 called\n");
  return d;
}

//POPCobject* POPCobject::m13() {printf("  m13 called\n");}
//POPCobject* POPCobject::m14() {printf("  m14 called\n");}

 //StructData* POPCobject::m15() {printf("  m15 called\n");}
 //StructData* POPCobject::m16() {printf("  m16 called\n");}

//StructData& POPCobject::m17() {printf("  m17 called\n");}
//StructData& POPCobject::m18() {printf("  m18 called\n");}

//POPCobject& POPCobject::m19() {printf("  m19 called\n");}
//POPCobject& POPCobject::m20() {printf("  m20 called\n");}

@pack(POPCobject);
