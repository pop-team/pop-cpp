import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.InputStreamRequestEntity;
import org.apache.commons.httpclient.methods.PostMethod;


public class PopCServlet extends HttpServlet {
	
  public void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException
  {

  	
  	HttpClient httpClient;
	PostMethod post;
	String url;
	OutputStream toClient;
	InputStream fromClient;
	
	toClient = response.getOutputStream();
	fromClient = request.getInputStream();
  	
	HttpSession session = request.getSession(true);
	int i = session.getMaxInactiveInterval();
  	try 
	{
  	  	//int msgSize = request.getContentLength();
    	   	    	    	
    	if(session.isNew())
    	{
			httpClient=new HttpClient();
    		url=request.getParameter("url");
    
    		session.setAttribute("client", httpClient);
	    	session.setAttribute("url", url);
	    	
    	}   
    	else
    	{
    		httpClient=(HttpClient)session.getAttribute("client");
    		url = (String)session.getAttribute("url");
    	}

    	String connection = request.getParameter("close");
    	if(connection!=null && connection.equalsIgnoreCase("true"))
    	{
    		try
			{
    			String sessionID = session.getId();
    			post = new PostMethod(url);
    			post.addRequestHeader("Connection", "close");
	    		post.setQueryString(request.getQueryString());
	    		post.setRequestEntity(new InputStreamRequestEntity(fromClient));
	        	httpClient.executeMethod(post);
	        	if (post.getStatusCode() == HttpStatus.SC_OK) {
	        		byte[] responseBuffer=post.getResponseBody();
	        		response.setContentLength(responseBuffer.length);
	        		toClient.write(responseBuffer);
	    	    	toClient.flush();
	    	    	session.invalidate();
	    	    	return;
	            } 
	        	else
	        	{
	        		throw new Exception();
	        	}
			}
    		catch (Exception e) 
			{
    			response.sendError(500); //Catch the exception here...
    			session.invalidate();
    			return;
			}
    	}
    	post = new PostMethod(url);
    	post.setRequestEntity(new InputStreamRequestEntity(fromClient));
    	httpClient.executeMethod(post);
    	
    	if (post.getStatusCode() == HttpStatus.SC_OK) {
    		byte[] responseBuffer=post.getResponseBody();
    		response.setContentLength(responseBuffer.length);
    		toClient.write(responseBuffer);
	    	toClient.flush();
        } 
    	else
    	{
    		throw new Exception();
    	}
	}
	catch (Exception e) 
	{
		session.invalidate();
		response.sendError(500);
	}
	}
}