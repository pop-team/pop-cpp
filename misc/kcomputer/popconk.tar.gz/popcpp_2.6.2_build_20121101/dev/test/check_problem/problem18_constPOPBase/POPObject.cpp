#include "POPObject.h"



POPObject::POPObject()
{

  
}

POPObject::~POPObject()
{
  
}

void POPObject::transferPOPBaseData(const POPData d){
	int i = d.getIntData();
	
}