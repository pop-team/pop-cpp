#ifndef POPOBJECT_PH_
#define POPOBJECT_PH_

#include "POPData.h"

class POPObject {

public:
	POPObject();
	~POPObject();
	
	void transferPOPBaseData(const POPData d);	
		
private:

};

#endif /*POPOBJECT_PH_*/
