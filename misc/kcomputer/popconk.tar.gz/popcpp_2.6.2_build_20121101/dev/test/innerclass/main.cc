#include "POPObject.ph"

/** 
 * @author  clementval
 * @date    2011.11.28
 * This program is testing enum declaration inside a parclass
 */
int main(int argc, char** argv)

{
	POPObject o;
	
	return 0;
}
