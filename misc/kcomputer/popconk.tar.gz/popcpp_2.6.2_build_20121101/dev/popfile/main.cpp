/**
 * File: main.cpp
 * Author: Valentin Clement (clementval)
 * Description: Dummy main for the library compilation
 * Creation date: 03.25.2012
 * 
 * Change Log: 
 * Author		Date			Description
 * clementval	03.25.2012	Creation of this file
 */
int main(int argc, char** argv)
{
	return 0;	
}


