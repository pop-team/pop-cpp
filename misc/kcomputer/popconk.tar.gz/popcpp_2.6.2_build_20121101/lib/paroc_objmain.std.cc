/**
 * File : paroc_objmain.std.cc
 * Author : Tuan Anh Nguyen
 * Description : "main" entry for the object executable
 * Initialization of parallel objects
 * The Job service can pass to a parallel object environment by:
 * 1- Specify the argument -jobservice=<code services...> when launching the object binary code (not used by the Interface)
 * 2- Set environment variable "POPC_JOBSERVICE to the job service point
 * 3- <localhost>:2711 ( if 1/ and 2/ are not specified )
 * Creation date : -
 * 
 * Modifications :
 * Authors		Date			Comment
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <signal.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "paroc_broker.h"
#include "paroc_broker_factory.h"

//#include "appservice.ph"
#include "paroc_buffer_factory_finder.h"

bool CheckIfPacked(const char *objname);

//extern paroc_broker *InitBroker(char *objname);
//extern void QueryObjectList(char *str, int n);


int main(int argc, char **argv)
{
	char *rcore=paroc_utils::checkremove(&argc,&argv,"-core=");
	if (rcore!=NULL) {
		paroc_system::processor_set(atoi(rcore));
	}
#ifdef UC_LINUX
	else paroc_system::processor_set(0);
#endif

	paroc_system sys;
	char *local_rank = paroc_utils::checkremove(&argc, &argv, "-local_rank=");
	if(local_rank != NULL) {
  	paroc_system::popc_local_mpi_communicator_rank = atoi(local_rank);
	}
  

	// Connect to callback
	char *address = paroc_utils::checkremove(&argc, &argv, "-callback=");
	paroc_combox *callback = NULL;
	int status=0;
	if (address != NULL) {
	  paroc_combox_factory *combox_factory = paroc_combox_factory::GetInstance();
	  callback = combox_factory->Create("uds");
	  if(!callback->Create(address, false)) {
  	  callback->Close();
    	callback->Destroy();
			printf("POP-C++ Error: fail to connect to callback. Check that the URL %s belongs to a node.\n", address);
			return 1;
	  }
	    
    if(!callback->Connect(address)){
  	  callback->Close();
    	callback->Destroy();
			printf("POP-C++ Error: fail to connect to callback. Check that the URL %s belongs to a node.\n", address);
			return 1;    	
    }	  	
	}

	paroc_broker_factory::CheckIfPacked = &CheckIfPacked; // transmit the address of the check function to broker factory
	paroc_broker *broker = paroc_broker_factory::Create(&argc,&argv);
	if (broker == NULL) {
		status = 1;
	} else if (!broker->Initialize(&argc, &argv)) {
		//Initialize broker...
		printf("Fail to initialize the broker for class %s\n",(const char *)paroc_broker::classname);
		status = 1;
	}


	// Send ack via callback
	if (callback != NULL) {
	  paroc_buffer *buffer = callback->GetBufferFactory()->CreateBuffer();
		paroc_message_header h(0, 200002, INVOKE_SYNC, "_callback");
		buffer->SetHeader(h);
		
    paroc_connection* connection = callback->get_connection();	
    bool ret = buffer->Send((*callback), connection); 
		buffer->Destroy();
		callback->Destroy();
		if (!ret) {
			printf("POP-C++ Error: fail to send accesspoint via callback\n");
			delete broker;
			return 1;
		}
	} else if (status == 0) {
		fprintf(stdout, "%s\n", (const char *)paroc_broker::accesspoint.GetAccessString());
	}
	
	// set the current working directory
	char *cwd = paroc_utils::checkremove(&argc,&argv,"-cwd=");
	if (cwd!=NULL) {
		if (chdir(cwd)!=0)
			DEBUG("current working dir cannot be set set to %s",cwd);
	}

	// Start the broker
	if (status==0) {
		broker->Run();
		delete broker;
	} else if (broker!=NULL) { 
	  delete broker;
	}

	return status;
}






