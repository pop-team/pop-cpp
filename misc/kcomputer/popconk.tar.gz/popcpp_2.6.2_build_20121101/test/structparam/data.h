#ifndef _DATA_H_
#define _DATA_H_


struct oneData
{
  int theData;
};

typedef struct oneData Data;

#endif    
