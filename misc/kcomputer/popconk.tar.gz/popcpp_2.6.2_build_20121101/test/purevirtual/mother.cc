#include "mother.ph"


Mother::Mother()
{

}

Mother::~Mother()
{
}