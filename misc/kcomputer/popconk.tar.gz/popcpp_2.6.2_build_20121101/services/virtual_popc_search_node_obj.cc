/*
	File added by clementval.
	Allow the creation of a executable POPCSearchNode object as a service
*/

#include "virtual_popc_search_node.ph"

@pack(VirtualPOPCSearchNode, POPCSearchNode)
