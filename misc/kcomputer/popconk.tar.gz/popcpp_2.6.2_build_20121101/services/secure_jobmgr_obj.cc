#include "secure_jobmgr.ph"

@pack(SecureJobMgr, JobMgr)

