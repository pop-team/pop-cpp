#include "appservice.ph"

@pack(AppCoreService, CodeMgr, RemoteLog, BatchMgr)

