#include "virtual_popc_security_manager.ph"

@pack(VirtualPOPCSecurityManager, POPCSecurityManager)
