/*
	File added by clementval.
	Allow the creation of a executable POPCSearchNode object as a service
*/

#include "secure_popc_search_node.ph"

@pack(SecurePOPCSearchNode, POPCSearchNode)
